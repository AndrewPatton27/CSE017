import java.util.Comparator;

/** Orders students by name A-Z. */
public class ComparatorByName implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        return s1.getName().compareTo(s2.getName());
    }
}
