import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

/** Java Collection Framework drills: Iterator, ListIterator, Collections, Stack, Queue, PriorityQueue. */
public class CollectionsDrills {

    /** Remove every negative number IN PLACE with Iterator.remove() (not list.remove -> ConcurrentModificationException). */
    public static void removeNegatives(List<Integer> list) {
        Iterator<Integer> it = list.iterator();
        while (it.hasNext()) {
            if (it.next() < 0) {
                it.remove();
            }
        }
    }

    /** New list with the elements in reverse order, built with a ListIterator walking BACKWARD. */
    public static <E> List<E> reversedCopy(List<E> list) {
        List<E> result = new ArrayList<>();
        ListIterator<E> it = list.listIterator(list.size());
        while (it.hasPrevious()) {
            result.add(it.previous());
        }
        return result;
    }

    /** Double every value in place using ListIterator.set(). */
    public static void doubleAll(List<Integer> list) {
        ListIterator<Integer> it = list.listIterator();
        while (it.hasNext()) {
            int value = it.next();
            it.set(value * 2);
        }
    }

    /** Sort by string length (shortest first) using Collections.sort and a Comparator. Ties keep their order (sort is stable). */
    public static void sortByLength(List<String> words) {
        Collections.sort(words, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return a.length() - b.length();
            }
        });
    }

    /** Largest value using only Collections methods (no loop). list is non-empty. */
    public static int largest(List<Integer> list) {
        return Collections.max(list);
    }

    /** Stack: are the brackets ( ) [ ] { } balanced? "([]{})" true, "(]" false, "((" false. */
    public static boolean isBalanced(String s) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                stack.push(c);
            } else if (c == ')' || c == ']' || c == '}') {
                if (stack.isEmpty()) {
                    return false;
                }
                char open = stack.pop();
                if (!matches(open, c)) {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    private static boolean matches(char open, char close) {
        return (open == '(' && close == ')')
            || (open == '[' && close == ']')
            || (open == '{' && close == '}');
    }

    /** Reverse a queue IN PLACE using a stack. Queue API: offer / poll / peek. */
    public static void reverseQueue(Queue<Integer> q) {
        Stack<Integer> stack = new Stack<>();
        while (!q.isEmpty()) {
            stack.push(q.poll());
        }
        while (!stack.isEmpty()) {
            q.offer(stack.pop());
        }
    }

    /**
     * Hot potato (Josephus): names sit in a circle, every k-th person is out.
     * Use a queue: poll k-1 people and offer them to the back, then poll (out) the k-th.
     * Return the winner (the last one left).
     */
    public static String hotPotato(List<String> names, int k) {
        Queue<String> q = new LinkedList<>(names);
        while (q.size() > 1) {
            for (int i = 1; i < k; i++) {
                q.offer(q.poll());
            }
            q.poll();
        }
        return q.peek();
    }

    /** The k largest values, biggest first. Use a PriorityQueue (min-heap of size k) - natural order is smallest first. */
    public static List<Integer> kLargest(int[] a, int k) {
        PriorityQueue<Integer> heap = new PriorityQueue<>();
        for (int value : a) {
            heap.offer(value);
            if (heap.size() > k) {
                heap.poll();
            }
        }
        List<Integer> result = new ArrayList<>();
        while (!heap.isEmpty()) {
            result.add(heap.poll());
        }
        Collections.reverse(result);
        return result;
    }

    /** Names of the tasks in the order they should be done (uses Task natural ordering in a PriorityQueue). */
    public static List<String> doTasks(List<Task> tasks) {
        PriorityQueue<Task> pq = new PriorityQueue<>();
        for (Task t : tasks) {
            pq.offer(t);
        }
        List<String> order = new ArrayList<>();
        while (!pq.isEmpty()) {
            order.add(pq.poll().getName());
        }
        return order;
    }

    /** Same, but the most LOW priority first, using a PriorityQueue built with a Comparator (reverse of natural). */
    public static List<String> doTasksLeastUrgentFirst(List<Task> tasks) {
        PriorityQueue<Task> pq = new PriorityQueue<>(Collections.reverseOrder());
        pq.addAll(tasks);
        List<String> order = new ArrayList<>();
        while (!pq.isEmpty()) {
            order.add(pq.poll().getName());
        }
        return order;
    }

    /**
     * Use the Collection interface only: elements in BOTH lists, no loops
     * (hint: copy list a into a new ArrayList, then retainAll).
     */
    public static List<Integer> common(List<Integer> a, List<Integer> b) {
        List<Integer> copy = new ArrayList<>(a);
        copy.retainAll(b);
        return copy;
    }
}
