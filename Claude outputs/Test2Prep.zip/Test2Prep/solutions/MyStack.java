import java.util.ArrayList;

/**
 * Generic stack backed by an ArrayList (end of the list = top).
 * pop/peek on an empty stack throw RuntimeException("empty stack").
 * @param <E> element type
 */
public class MyStack<E> {
    private ArrayList<E> elements = new ArrayList<>();

    public int size() {
        return elements.size();
    }

    public boolean isEmpty() {
        return elements.isEmpty();
    }

    public void push(E item) {
        elements.add(item);
    }

    public E peek() {
        if (isEmpty()) {
            throw new RuntimeException("empty stack");
        }
        return elements.get(size() - 1);
    }

    public E pop() {
        if (isEmpty()) {
            throw new RuntimeException("empty stack");
        }
        return elements.remove(size() - 1);
    }

    @Override
    public String toString() {
        return "Stack: " + elements;
    }
}
