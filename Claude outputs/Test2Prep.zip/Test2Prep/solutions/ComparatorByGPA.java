import java.util.Comparator;

/** Orders students by GPA, HIGHEST first. (doubles: use Double.compare or compareTo) */
public class ComparatorByGPA implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        return Double.compare(s2.getGPA(), s1.getGPA());
    }
}
