import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Recursion drills. Every method must be recursive (no loops!).
 * Run DrillTest to check your work.
 */
public class RecursionDrills {

    /** Sum of the digits of n (n >= 0). sumDigits(1234) = 10. */
    public static int sumDigits(int n) {
        if (n < 10) {                       // base case: one digit
            return n;
        }
        return n % 10 + sumDigits(n / 10);  // last digit + rest
    }

    /** base^exp for exp >= 0 (O(n) version, one multiplication per call). */
    public static int power(int base, int exp) {
        if (exp == 0) {
            return 1;
        }
        return base * power(base, exp - 1);
    }

    /** base^exp in O(log n): square the half. power2(2, 10) = 1024. */
    public static long power2(long base, int exp) {
        if (exp == 0) {
            return 1;
        }
        long half = power2(base, exp / 2);
        if (exp % 2 == 0) {
            return half * half;
        }
        return base * half * half;
    }

    /** Reverse a string. reverse("abc") = "cba". */
    public static String reverse(String s) {
        if (s.length() <= 1) {
            return s;
        }
        return reverse(s.substring(1)) + s.charAt(0);
    }

    /** True if s reads the same both ways. Use a helper with two indexes. */
    public static boolean isPalindrome(String s) {
        return isPalindrome(s, 0, s.length() - 1);
    }

    // helper (overloaded): carries the two ends
    private static boolean isPalindrome(String s, int first, int last) {
        if (first >= last) {
            return true;
        }
        if (s.charAt(first) != s.charAt(last)) {
            return false;
        }
        return isPalindrome(s, first + 1, last - 1);
    }

    /** Count the even numbers in the array. Helper carries the index. */
    public static int countEven(int[] a) {
        return countEven(a, 0);
    }

    private static int countEven(int[] a, int index) {
        if (index == a.length) {
            return 0;
        }
        int here = a[index] % 2 == 0 ? 1 : 0;
        return here + countEven(a, index + 1);
    }

    /** Recursive binary search on a SORTED array. Returns index or -1. */
    public static int binarySearch(int[] a, int key) {
        return binarySearch(a, key, 0, a.length - 1);
    }

    private static int binarySearch(int[] a, int key, int first, int last) {
        if (first > last) {
            return -1;
        }
        int mid = (first + last) / 2;
        if (key == a[mid]) {
            return mid;
        } else if (key < a[mid]) {
            return binarySearch(a, key, first, mid - 1);
        }
        return binarySearch(a, key, mid + 1, last);
    }

    /** Greatest common divisor (Euclid). gcd(12, 18) = 6. */
    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

    /** Binary representation as a String. toBinary(10) = "1010", toBinary(0) = "0". */
    public static String toBinary(int n) {
        if (n < 2) {
            return String.valueOf(n);
        }
        return toBinary(n / 2) + (n % 2);
    }

    /** Number of times target appears in the list. Recursive + iterator. */
    public static int countOccurrences(List<String> list, String target) {
        return countOccurrences(list.iterator(), target);
    }

    private static int countOccurrences(Iterator<String> it, String target) {
        if (!it.hasNext()) {
            return 0;
        }
        int here = it.next().equals(target) ? 1 : 0;
        return here + countOccurrences(it, target);
    }

    /**
     * Exam style (like findMessages in Practice Test 2): return a NEW list with
     * every element >= min, or null if there are none. Recursive + iterator.
     */
    public static List<Integer> findAtLeast(List<Integer> list, int min) {
        List<Integer> result = new ArrayList<>();
        findAtLeast(list.iterator(), min, result);
        return result.isEmpty() ? null : result;
    }

    private static void findAtLeast(Iterator<Integer> it, int min, List<Integer> result) {
        if (!it.hasNext()) {
            return;
        }
        int value = it.next();
        if (value >= min) {
            result.add(value);
        }
        findAtLeast(it, min, result);
    }

    /** Largest value in a non-empty list using an iterator. */
    public static int maxOf(List<Integer> list) {
        Iterator<Integer> it = list.iterator();
        return maxOf(it, it.next());
    }

    private static int maxOf(Iterator<Integer> it, int best) {
        if (!it.hasNext()) {
            return best;
        }
        int value = it.next();
        return maxOf(it, Math.max(best, value));
    }

    /**
     * No base case on purpose! Calling this throws StackOverflowError.
     * (Do not fix it. DrillTest catches the error to show what happens.)
     */
    public static int brokenFactorial(int n) {
        return n * brokenFactorial(n - 1);
    }
}
