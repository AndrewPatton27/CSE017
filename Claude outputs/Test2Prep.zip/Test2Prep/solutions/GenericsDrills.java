import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * Generic method drills. Remember the restrictions:
 * no new E(), no new E[n], and E must be a reference type.
 */
public class GenericsDrills {

    /** How many elements of arr equal key (use equals). */
    public static <E> int count(E[] arr, E key) {
        int total = 0;
        for (E item : arr) {
            if (item.equals(key)) {
                total++;
            }
        }
        return total;
    }

    /** Largest element. Needs a bound so we can call compareTo. arr is non-empty. */
    public static <E extends Comparable<E>> E max(E[] arr) {
        E best = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i].compareTo(best) > 0) {
                best = arr[i];
            }
        }
        return best;
    }

    /** Swap arr[i] and arr[j]. */
    public static <E> void swap(E[] arr, int i, int j) {
        E temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    /** Reverse the array in place (call your swap). */
    public static <E> void reverse(E[] arr) {
        for (int i = 0; i < arr.length / 2; i++) {
            swap(arr, i, arr.length - 1 - i);
        }
    }

    /** True if the list is in ascending order (ties allowed). Use an iterator. */
    public static <E extends Comparable<E>> boolean isSorted(List<E> list) {
        Iterator<E> it = list.iterator();
        if (!it.hasNext()) {
            return true;
        }
        E previous = it.next();
        while (it.hasNext()) {
            E current = it.next();
            if (previous.compareTo(current) > 0) {
                return false;
            }
            previous = current;
        }
        return true;
    }

    /** How many elements are strictly greater than key. */
    public static <E extends Comparable<E>> int countGreater(List<E> list, E key) {
        int total = 0;
        for (E item : list) {
            if (item.compareTo(key) > 0) {
                total++;
            }
        }
        return total;
    }

    /** New list with the duplicates removed (first occurrence kept). O(n^2). */
    public static <E> List<E> removeDuplicates(List<E> list) {
        List<E> result = new ArrayList<>();
        for (E item : list) {
            if (!result.contains(item)) {
                result.add(item);
            }
        }
        return result;
    }

    /** Put all of list1 then all of list2 into out. O(n). */
    public static <E> void union(List<E> list1, List<E> list2, List<E> out) {
        Iterator<E> i1 = list1.iterator();
        while (i1.hasNext()) {
            out.add(i1.next());
        }
        Iterator<E> i2 = list2.iterator();
        while (i2.hasNext()) {
            out.add(i2.next());
        }
    }

    /** Elements of list1 that are also in list2 (list1 order, keeps list1 duplicates). O(n^2). */
    public static <E> void intersection(List<E> list1, List<E> list2, List<E> out) {
        Iterator<E> i1 = list1.iterator();
        while (i1.hasNext()) {
            E item = i1.next();
            if (list2.contains(item)) {
                out.add(item);
            }
        }
    }

    /** Elements of list1 that are NOT in list2. O(n^2). */
    public static <E> void difference(List<E> list1, List<E> list2, List<E> out) {
        Iterator<E> i1 = list1.iterator();
        while (i1.hasNext()) {
            E item = i1.next();
            if (!list2.contains(item)) {
                out.add(item);
            }
        }
    }

    /** Insertion sort with a Comparator (this is how Arrays.sort(arr, c) is used). */
    public static <E> void insertionSort(E[] arr, Comparator<E> c) {
        for (int i = 1; i < arr.length; i++) {
            E current = arr[i];
            int j = i - 1;
            while (j >= 0 && c.compare(arr[j], current) > 0) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = current;
        }
    }

    /**
     * Total of a list of ANY Number subtype. Wildcard practice:
     * List<? extends Number> can be read as Number but not added to.
     */
    public static double total(List<? extends Number> list) {
        double sum = 0;
        for (Number n : list) {
            sum += n.doubleValue();
        }
        return sum;
    }
}
